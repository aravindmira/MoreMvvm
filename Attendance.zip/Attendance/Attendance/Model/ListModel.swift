//
//  ListModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct ListModel: Codable{
 let compliance_list : [complianceList]
 let total_count : String?
}
struct complianceList:Codable {
    let site_address : String?
    let site_id : String?
    let site_inspection_date : String?
    let site_name : String?
    let site_state : String?
    let site_suburb : String?
    let site_visit_month : String?
}

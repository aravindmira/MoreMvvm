//
//  LoginModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct LoginResModel: Codable{    
 let user_auth_token : String?
 let user_email : String?
 let user_group_id : String?
 let user_id : String?
 let user_login : String?
 let user_name : String?
 let ErrorAction :String?
 let ErrorCode :Int?
 let ErrorMessage :String?
 let ErrorStatus :String?
}


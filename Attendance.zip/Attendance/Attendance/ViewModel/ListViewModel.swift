//
//  ListViewModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct ListViewModel {
    var compliance_list : [complianceList]?
    var total_count : String?
    var site_addressArr = [String]()
    mutating func setup(vm:ListModel){
        total_count = vm.total_count
        compliance_list = vm.compliance_list
        for cl in compliance_list ?? []{
            site_addressArr.append(cl.site_address ?? "")
        }
    }
    func getNumberOfRowsInSection() -> Int{
        
        return compliance_list?.count ?? 0
    }
    func dataAtIndex(at index: Int) -> complianceList{
        
        return (compliance_list?[index])!
    }
    
}


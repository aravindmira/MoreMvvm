//
//  LoginViewModel.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
struct LoginViewModel {
    var user_auth_token : String?
    var user_email : String?
    var user_group_id : String?
    var user_id : String?
    var user_login : String?
    var user_name : String?
    var ErrorAction :String?
    var ErrorCode :Int?
    var ErrorMessage :String?
    var ErrorStatus :String?
    
    func checkUsersInputs (username:String,password:String) ->Bool{
        if (username.count >= 2 && password.count >= 2){
            return true
        }else{
            return false
        }
    }
    mutating func setup(vm :LoginResModel){
        user_auth_token = vm.user_auth_token
        user_email = vm.user_email
        user_group_id = vm.user_group_id
        user_id = vm.user_id
        user_login = vm.user_login
        user_name = vm.user_name
        ErrorAction = vm.ErrorAction
        ErrorCode = vm.ErrorCode
        ErrorMessage = vm.ErrorMessage
        ErrorStatus = vm.ErrorStatus
        if(ErrorStatus == nil){
            UserDefaults.standard.set(user_auth_token, forKey: "ud_auth_token")
            UserDefaults.standard.set(user_id, forKey: "user_id")
        }
    }
}

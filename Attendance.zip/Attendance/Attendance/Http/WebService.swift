//
//  WebService.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
enum NetworkError: Error {
    case decodingError
    case domainError
    case urlError
}
enum HttpMethod: String {
    case get = "GET"
    case post = "POST"
}

struct Resource<T: Codable> {
    let url: URL
    var httpMethod: HttpMethod = .get
    var body: Data? = nil
    init(url: URL,httpMethod: HttpMethod, body: Data? = nil) {
        self.url = url
        self.httpMethod = httpMethod
        self.body = body
    }
}


class WebService {
    func load<T>(resource: Resource<T>, completion: @escaping (Result<T, NetworkError>) -> Void) {
        var request = URLRequest(url: resource.url)
        request.httpMethod = resource.httpMethod.rawValue
        request.httpBody = resource.body
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")

        print(request)
      let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                completion(.failure(.domainError))
                return
            }
            do {
                let returnData = (try JSONSerialization.jsonObject(with: data, options:JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary)
                print("response",returnData )
    
                                                                               
                } catch {
                        print("Something went wrong")
                                                                                            }

            let result = try? JSONDecoder().decode(T.self, from: data)
        print("Actuall response ",result ?? "")
            if let result = result {
                DispatchQueue.main.async {
                    completion(.success(result))
                }
            } else {
                completion(.failure(.decodingError))
            }
            
      }
        task.resume()
        
        
    }
}

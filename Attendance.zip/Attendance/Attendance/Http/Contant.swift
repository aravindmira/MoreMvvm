//
//  Contant.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import Foundation
let baseUrl = "http://stage.bossint.com.au/mobileappapi/"
struct api{
  static  let loginUrl = "\(baseUrl)appapi_login.aspx?"
  static  let listUrl = "\(baseUrl)appapi_compliance_list.aspx?"
}

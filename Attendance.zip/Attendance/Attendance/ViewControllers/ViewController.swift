//
//  ViewController.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 23/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    private var lvm = LoginViewModel()
    @IBOutlet var UserNameTF: UITextField!
    @IBOutlet weak var PassWordTF: UITextField!
    @IBOutlet weak var LogInBT: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func LogInBTAction(_ sender: Any) {
        if lvm.checkUsersInputs(username: UserNameTF.text ?? "", password: PassWordTF.text ?? "") {
            let loginStr = "username=\(UserNameTF.text ?? "")&Password=\(PassWordTF.text ?? "")"
            let data = loginStr.data(using: .utf8)
            WebService().load(resource: Resource<LoginResModel>(url: URL(string: api.loginUrl)!, httpMethod: HttpMethod.post, body:data)){ result in
                switch result {
                case .success(let ARes):
                print(ARes)
                self.lvm.setup(vm: ARes)
                if self.lvm.ErrorAction != nil {
                    self.popupAlert(title: "Title", message: " Oops, xxxx ", actionTitles: ["Option1","Option2"], actions:[{action1 in
                        
                        },{action2 in
                            
                        }, nil])
                }else{
                    let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "ListVC") as? ListVC
                    self.navigationController?.pushViewController(vc!, animated: true)
                    }
                    
                    
                case .failure(let error):
                    print(error)
                }
            }
            
        }else{
            self.popupAlert(title: "Title", message: " Oops, xxxx ", actionTitles: ["Option1","Option2"], actions:[{action1 in
                
                },{action2 in
                    
                }, nil])
        }
        
    }
}



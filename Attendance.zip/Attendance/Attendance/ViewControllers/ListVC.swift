//
//  ListVC.swift
//  Attendance
//
//  Created by Aravindakumar Arunachalam on 25/01/20.
//  Copyright © 2020 Aravindakumar Arunachalam. All rights reserved.
//

import UIKit

class ListVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    private var lvm = ListViewModel()
    @IBOutlet weak var TV: UITableView!
    var offset=Int()
    var PageCount=Int()
    var RecordCount=Int()
    var TotalCount = Int()
    var RespArr = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        PageCount = 50
         offset = 1
        loadData(offset: 0, pagesize: 50, searchkey: "", alphabet_sorting: "")
    }
    func loadData(offset:Int,pagesize:Int,searchkey:String,alphabet_sorting:String){
        let postStr = "user_id=2601&user_auth_token=f7c4014af0735871993a8b66ca54172a&compliance_type=compliance_site_90_days&offset=\(offset)&pagesize=\(pagesize)&searchkey=\(searchkey)&alphabet_sorting=\(alphabet_sorting)"
        print(postStr)
        let data = postStr.data(using: .utf8)
        WebService().load(resource: Resource<ListModel>(url: URL(string: api.listUrl)!, httpMethod: HttpMethod.post, body:data)){ result in
            switch result {
            case .success(let ListRes):
                self.lvm.setup(vm: ListRes)
                print(self.lvm.site_addressArr)
                self.TotalCount = Int(self.lvm.total_count ?? "0") ?? 0
                print("TotalCount",self.TotalCount)
                self.TV.isScrollEnabled = true
                //   print(self.lvm.compliance_list)
               // self.RespArr = self.lvm.compliance_list as! NSMutableArray
                self.TV.reloadData()
            case .failure(let error):
                print(error)
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lvm.site_addressArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier:String = "ListCell"
        let cell:ListCell? = tableView.dequeueReusableCell(withIdentifier: cellIdentifier) as? ListCell
       // let vm = lvm.dataAtIndex(at: indexPath.row)
        //let vm = RespArr.object(at: indexPath.row)
        //cell?.TitleLbl.text = (RespArr[indexPath.row] as AnyObject).value(forKey: "site_address") as? String
      //  RespArr.object(at: indexPath.row)
        cell?.TitleLbl.text = lvm.site_addressArr[indexPath.row]
        return cell!
    }
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        print("tot",TotalCount)
        var currentOffset = NSInteger()
        var maximumOffset = NSInteger()
        currentOffset = NSInteger(scrollView.contentOffset.y);
        maximumOffset = NSInteger(scrollView.contentSize.height-scrollView.frame.size.height)
        let value = maximumOffset - currentOffset
        if(value <= 0 ){
                self.TV.isScrollEnabled = false
            if(lvm.site_addressArr.count < TotalCount){
                if(RecordCount==PageCount){
                    offset = offset+PageCount

                }else{
                    offset = offset+lvm.getNumberOfRowsInSection()
                }
                // load function
                loadData(offset: offset, pagesize: PageCount, searchkey: "", alphabet_sorting: "")
            }else{
                
            }

        }


        // loadData(offset: 51, pagesize: 50, searchkey: "", alphabet_sorting: "")
    }
        
}
